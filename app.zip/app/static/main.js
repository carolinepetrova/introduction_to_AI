const submitRequest = (url, body) => {
    var response = fetch(url, {
            method: 'post',
            body: JSON.stringify(body),
            headers: new Headers({
                "content-type": "application/json"
            })
        }).then(response => {
            return response.json();
        })
        .then((json) => {
            return json;
        })
        .catch(error => console.error(error));
    return response;
}

const classify = async () => {
    var elem = document.getElementById("image").value;
    var body = {
        image: elem
    }
    var response = await submitRequest(`${window.origin}/predict`, body);
    console.log(response);
    var output = document.getElementById("output");
    var img_orig = document.getElementById("img-original");
    output.innerHTML = "<h2>Изход: <b>" + response['prediction'] + "</b></h2>";
    img_orig.innerHTML = '<img src="' + elem + '" class="">';
}