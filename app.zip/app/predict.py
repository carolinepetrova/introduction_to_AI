import flask
from tensorflow import keras
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing.image import img_to_array
from PIL import Image, ImageOps
from urllib.request import urlopen, Request
import ssl
import numpy as np
from flask import render_template


app = flask.Flask(__name__)
model = load_model('model.h5')

# ПОПЪЛВАТЕ ТУК КЛАСОВЕТЕ В РЕДА, КОЙТО СТЕ ГИ ЗАДАЛИ НА Teachable Machine
CLASSES = [
    "Dog",
    "Cat",
    "Rabbit"
]

# помощна функция, която трансформира снимката в числови стойности
def load_image(image):
    data = np.ndarray(shape=(1, 224, 224, 3), dtype=np.float32)
    image = Image.open(image).convert('RGB')
    size = (224, 224)
    image = ImageOps.fit(image, size, Image.ANTIALIAS)
    image_array = np.asarray(image)
    normalized_image_array = (image_array.astype(np.float32) / 127.0) - 1
    data[0] = normalized_image_array
    return data


@app.route("/", methods=["GET", "POST"])
def index():
    return render_template("index.html")


@app.route("/predict", methods=["POST"])
def predict():
    data = {}
    # извличаме снимката от POST заявката
    params = flask.request.json
    if (params == None):
        params = flask.request.args
    if (params != None):
        context = ssl._create_unverified_context()
        req = Request(params.get("image"), headers={
                      'User-Agent': 'Mozilla/5.0'})
        # преоразмеряваме снимката и я превръщаме в числови стойности
        image = load_image(urlopen(req, context=context))
        # даваме я на модела
        result = model.predict(image)
        # моделът връща списък от вероятности за всеки клас. Тук вземаме индексът на най-високата стойности
        index = np.argmax(result)
        prediction = CLASSES[index]
        # връщаме информацията под формата на JSON обект
        data["prediction"] = prediction
    return flask.jsonify(data)


# стартираме приложението на localhost:5000
app.run(port=5000)
